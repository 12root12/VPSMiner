class db():
    def write(cic,bal,dol,cor):
        dump=open('log.db')
        dump=dump.read()
        dump.close()
        ww=open('log.db')
        newl=cic+':'+bal+':'+dol+':'+cor
        ww.write(dump+'\n'+newl)
    def dump_min():
        dump=open('log.db')
        mincic=0
        minbal=0
        mindol=0
        mincor=0
        for i in dump.readlines():
            if int(i.split(':')[0])<mincic:
                mincic=int(i.split(':')[0])
            if int(i.split(':')[1])<minbal:
                minbal=int(i.split(':')[1])
            if int(i.split(':')[2])<mindol:
                mindol=int(i.split(':')[2])
            if int(i.split(':')[3])<mincor:
                mincor=int(i.split(':')[3])
        print('min cicle = ',mincic)
        print('min balance = ',minbal)
        print('min dollares = ',mindol)
        print('min course = ',mincor)
        dump.close()
    def dump_max():
        dump=open('log.db')
        mincic=0
        minbal=0
        mindol=0
        mincor=0
        for i in dump.readlines():
            if int(i.split(':'))[0]>mincic:
                mincic=int(i.split(':')[0])
            if int(i.split(':')[1])>minbal:
                minbal=int(i.split(':')[1])
            if int(i.split(':')[2])>mindol:
                mindol=int(i.split(':')[2])
            if int(i.split(':')[3])>mincor:
                mincor=int(i.split(':')[3])
        print('max cicle = ',mincic)
        print('max balance = ',minbal)
        print('max dollares = ',mindol)
        print('m course = ',mincor)
        dump.close()
while True:
    print('1.min 2.max')
    a=input()
    if a=='1':
        db.dump_min()
    if a=='2':
        db.dump_max()
